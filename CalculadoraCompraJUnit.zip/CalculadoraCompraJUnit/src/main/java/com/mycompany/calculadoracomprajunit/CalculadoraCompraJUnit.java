/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadoracomprajunit;

/**
 *
 * @author Admin
 */
public class CalculadoraCompraJUnit {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
